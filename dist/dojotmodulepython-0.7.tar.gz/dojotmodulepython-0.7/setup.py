from setuptools import setup

setup(name='dojotmodulepython',
      version='0.7',
      description='dojot module',
      url='http://github.com/matheuscampanhaf',
      author='bla',
      author_email='bla@bla.com',
      license='MIT',
      packages=['dojotmodulepython'],
      install_requires=['requests',],
      zip_safe=False)