from .config import config

print(config.name)