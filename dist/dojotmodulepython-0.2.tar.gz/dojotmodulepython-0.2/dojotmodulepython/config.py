

class Config:

    def init(self):
        self.name = "matheus"

config = Config()

def foo():
    print("matheus campanha")