from setuptools import setup

setup(name='dojotmodulepython',
      version='0.2',
      description='dojot module',
      url='http://github.com/matheuscampanhaf',
      author='bla',
      author_email='bla@bla.com',
      license='MIT',
      packages=['dojotmodulepython'],
      zip_safe=False)