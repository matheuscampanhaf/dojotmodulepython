import requests
from .Config import config
import base64
import json


class Auth:

    def getManagementToken(self, tenant):

        userinfo = {
            "username": tenant,
            "service": config.dojot["managementService"]
        }

        jwt = "{}.{}.{}".format(base64.b64encode("model".encode()).decode(),
                                base64.b64encode(json.dumps(
                                    userinfo).encode()).decode(),
                                base64.b64encode("signature".encode()).decode())

        return jwt

    def getTenants(self):
        # url = conf.auth['host'] + "/admin/tenants"
        # ret = requests.get(
        #     url, headers={'authorization': self.getManagementToken(conf.dojot['managementService'])})

        # payload = ret.json()
        
        # return payload['tenants']
        return "tenants"

auth = Auth()