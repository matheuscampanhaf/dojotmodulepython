from .config import config
from .config import foo
