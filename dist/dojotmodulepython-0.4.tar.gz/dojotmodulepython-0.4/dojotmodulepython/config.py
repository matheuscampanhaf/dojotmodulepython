

class Config:

    def __init__(self):
        self.name = "matheus"

config = Config()

def foo():
    print("matheus campanha")